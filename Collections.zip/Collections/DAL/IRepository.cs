﻿using EntityClassesLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public interface IRepository<T>
    {
        void AddEmployee(T employee);
        void UpdateEmployee(Employee emp);
        void DeleteEmployee(int employeeId);
        List<T> GetAllEmployees();
        Employee GetEmployeeByID(int employeeID);
        //T GetEmployeeById(int emplId);
        void AddToFile(List<Employee> employees);
        void GetEmployeesFromFile();
    }
}

﻿using DAL;
using EntityClassesLib;

namespace BankServiceLayer
{
    public class BankServiceLayer
    {
        private CollectionRepo dal = new CollectionRepo();

        public List<Employee> HttpGetAllEmployees()
        {
            return this.dal.GetAllEmployees();
        }
        public void HttpPostEmployee(Employee newemployee)
        {
            this.dal.AddEmployee(newemployee);
        }

        public void PutEmployee(Employee employee) 
        {
            this.dal.UpdateEmployee(employee);
        }

        public void DeleteEmployee(int empid)
        {
            this.dal.DeleteEmployee(empid);
        }
        public void AddEmployeeToFile()
        {
            List<Employee> temp = dal.GetAllEmployees();
            dal.AddToFile(temp);
        }

        public void DisplayEmployeeFromFile()
        {
            List<Employee> tmp = dal.GetAllEmployees();
            dal.GetEmployeesFromFile();
        }

        public Employee GetEmployeeById(int empid) => this.dal.GetEmployeeByID(empid);

       

        public void PersistData()
        {
            this.dal.PersistData();
        }

        public void ReadData()
        {
            this.dal.ReadData();
        }



    }
}
﻿using DAL;
using EntityClassesLib;
namespace BankServiceLayer
{
    public class BankServiceLayer
    {
        //private CustomerCollectionRepo dal=new CustomerCollectionRepo();
        private CustomerDBRepo dal = new CustomerDBRepo();


        public List<Customer> HttpGetAllCustomers()
        {
            return this.dal.GetAllCustomers();
        }
        public void HttpPostCustomer(Customer newcustomer)
        {
            this.dal.AddNewCustomer(newcustomer);
        }
        public void PutCustomer(int custid, Customer modifiedcustomer)
        {
            this.dal.EditCustomer(custid, modifiedcustomer);
        }
        public void DeleteCustomer(int custid)
        {
            this.dal.DeleteCustomer(custid);
        }

        public void NewAccount(Account a)
        {
            this.dal.CreateAccount(a);
        }
        public List<Account> GetAccountsForCustomer(int cid)
        {
            return this.dal.GetAccountsForCustomer(cid);
        }
        public List<Account> GetAccounts(AccountType acctype)
        {
            return this.dal.GetAccounts(AccountType.Savings);
        }

        public double Transaction(string transaction, int accid, double amt)
        {
            return this.dal.Transaction(transaction, accid, amt);
        }

        public void PersistData()
        {
            this.dal.PersistData();
        }

        public void ReadData()
        {
            this.dal.ReadData();
        }




    }

}
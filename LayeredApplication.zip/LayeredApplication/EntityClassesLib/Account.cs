namespace EntityClassesLib
{

    public class Account
    {
        public int AccountId { get; set; }

        public AccountType AccType { get; set; }
        public int Balance { get; set; }
        public int CustomerId { get; set; }
    }
}

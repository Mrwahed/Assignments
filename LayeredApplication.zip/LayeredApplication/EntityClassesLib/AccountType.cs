namespace EntityClassesLib
{
    public enum AccountType
    {
        Savings,        //will have a value 0
        Salary              //will have a value 1
    }
}
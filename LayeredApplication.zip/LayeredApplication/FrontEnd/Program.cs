﻿using bl;
using EntityClassesLib;
using LoggerLib;
using System.Transactions;
using ValidationLayer;

namespace FrontEnd
{
    class Program
    {
        static BusinessLogic bl = new BusinessLogic();
        static bool IsDataRetrieved = false;

        static void Main()
        {

            int choice = -1;
            do
            {
                Console.Clear();
                Console.WriteLine("1. GET ALL CUSTOMERS");
                Console.WriteLine("2. ADD A NEW CUSTOMER");
                Console.WriteLine("3. EDIT CUSTOMER DETAILS");
                Console.WriteLine("4. REMOVE A CUSTOMER");
                Console.WriteLine("5. CREATE A NEW ACCOUNT ");
                Console.WriteLine("6. PERFORM A DEPOSIT OR WITHDRAW ");
                Console.WriteLine("7. SEARCH ACCOUNT BY CUST ID ");
                Console.WriteLine("8. SEARCH ACCOUNT BY ACC TYPE ");
                Console.WriteLine("9. QUIT ");
                if (File.Exists("c:\\customers.json"))
                {
                    if (IsDataRetrieved == false)
                    {
                        bl.ReadData();
                        IsDataRetrieved = true;
                    }
                }

                Console.Write("\nEnter your choice (1-9): ");
                choice = int.Parse(Console.ReadLine());

                //you can use a switch or if else to check the choice
                switch (choice)
                {
                    case 1:
                        GetAllCustomers();
                        break;
                    case 2:
                        AddCustomer();
                        break;
                    case 3:
                        EditCustomer();
                        break;
                    case 4:
                        DeleteCustomer();
                        break;
                    case 5:
                        CreateAccount();
                        break;
                    case 6:
                        PerformTransactions();
                        break;
                    case 7:
                        SearchAccountId();
                        break;
                    case 8:
                        SearchAccountType();
                        break;

                    case 9:
                        bl.PersistData();
                        Console.WriteLine("Thank you for using Simple CMS");
                        break;
                    default:
                        Console.WriteLine("Invalid Choice.Press any key to continue");
                        Console.ReadKey();
                        break;
                }



            } while (choice != 9);

        }

        
        static void GetAllCustomers()
        {
            Console.Clear();
            var result = bl.ObtainAllCustomerList();
            if (result.Count() == 0)
            {
                Console.WriteLine("No customers to show");
            }
            else
            {
                foreach (var customer in result)
                {
                    Console.WriteLine(customer);
                }
            }

            Console.ReadKey();
        }
        static void AddCustomer()
        {
            Console.Clear();
            Console.Write("Enter customer id: ");

            int cid = int.Parse(Console.ReadLine());

            if (Validator.ValidateCustomerId(cid) == false)
            {
                Console.WriteLine("Customer Id is not valid");
                Console.ReadKey();
                return;
            }
            Console.Write("Enter customer name: ");
            string cname = Console.ReadLine();
            Console.Write("Enter customer city: ");
            string city = Console.ReadLine();
            Console.Write("Enter customer state: ");
            string state = Console.ReadLine();
            bl.InsertCustomer(cid, cname, city, state);

        }
        static void EditCustomer()

        {
            Console.WriteLine("Enter Customer ID:");
            int cid = int.Parse(Console.ReadLine());
            Console.Write("Enter customer newname: ");
            string newname = Console.ReadLine();
            Console.Write("Enter customer newcity: ");
            string newcity = Console.ReadLine();
            Console.Write("Enter customer newstate: ");
            string newstate = Console.ReadLine();
            bl.ModifyCustomer(cid, newname, newcity, newstate);

            Console.ReadKey();


        }

        static void DeleteCustomer()
        {
            Console.WriteLine("Enter Customer ID:");
            int cid = int.Parse(Console.ReadLine());
            Console.WriteLine("Are you sure to Delete?\n Press 1 to remove customer\n Press 0 to abort");
            int del = int.Parse(Console.ReadLine());
            if (del == 1)
            {
                bl.RemoveCustomer(cid);

            }
            Console.ReadKey();
        }

        static void CreateAccount()
        {
            Console.Clear();
            Console.Write("New Acccount");
            Console.Write("Enter Account id: ");
            int accid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter 0-Saving and 1-Salary");
            int acctype = Convert.ToInt32(Console.ReadLine());
            AccountType accT = (AccountType)acctype;
            Console.Write("Enter Balance Amount : ");
            int balance = int.Parse(Console.ReadLine());
            Console.Write("Enter Customer id: ");
            int customerid = int.Parse(Console.ReadLine());


            bl.CreateAccount(accid, accT, balance, customerid);
        }

        static void PerformTransactions()
        {

            Console.Clear();
            Console.WriteLine("Enter the AccountID");
            int accid = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Withdraw and Deposit");
            //int transaction = Convert.ToInt32(Console.ReadLine());

            string t = (Console.ReadLine());
            string transaction = (string)t;
           

            //Console.WriteLine("\n ENTER THE DEPOSIT AMOUNT");
            //int deposit = int.Parse(Console.ReadLine());

         
            Console.WriteLine("Enter the Amount");
            int amt = int.Parse(Console.ReadLine());

            bl.Transaction(transaction, accid, amt);


            //Console.WriteLine("\n ENTER THE WITHDRAW AMOUNT : ");
            //int withdraw = int.Parse(Console.ReadLine());

            //if (withdraw % 100 != 0)
            //{
            //    Console.WriteLine("\n please enter the amount in above 100");
            //}
            //else if (withdraw > (amt - 1000))
            //{
            //    Console.WriteLine("\n sorry! insufficent balance");
            //}
            //else
            //{
            //    amt = amt - withdraw;
            //    Console.WriteLine("\n\n please collect your cash");
            //    Console.WriteLine("\n current balance is rs : {0}", amt);
            //}
            //Console.WriteLine("\n enter the deposit amount");
            //deposit = int.Parse(Console.ReadLine());
            //amt = amt + deposit;
            //Console.WriteLine("");

        }
        static void SearchAccountId()
        {
            Console.Clear();
            Console.Write("Enter customer id: ");

            int cid = int.Parse(Console.ReadLine());
            bl.GetAccountsForCustomer(cid);
            Console.ReadKey();
        }
        static void SearchAccountType()
        {
            Console.WriteLine("Enter the Account Type:");
            Console.WriteLine("Enter 0-Saving and 1-Salary");
            int acctype = Convert.ToInt32(Console.ReadLine());
            AccountType accT = (AccountType)acctype;
            bl.GetAccounts(accT);
            Console.ReadKey();
        }
    }
}

﻿using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using EntityClassesLib;
using LoggerLib;
using BankService = BankServiceLayer.BankServiceLayer;

namespace BL
{
    public class BusinessLogic
    {
        private BankService bsl = new BankService();

        private FileLogger? filelogger;

        public List<RevisedEmployee> ObtainAllEmployeesList()
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("ObtainAllEmployeesList() called at:" + DateTime.Now);
            }

            List<Employee> employees = bsl.HttpGetAllEmployees();

            List<RevisedEmployee> result = new List<RevisedEmployee>();

            foreach (Employee emp in employees)
            {
                RevisedEmployee re = new RevisedEmployee();

                re.EmpId = emp.EmployeeID;
                re.FName = emp.FirstName;
                re.LName = emp.LastName;
                re.Sal = emp.Salary;
                re.Doj = emp.DateofJoining;
                result.Add(re);

            }
            return result;

        }
        public void InsertEmployee(int empid, string fname, string lname, int sal, DateTime doj)

        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("InsertEmployee() called at:" + DateTime.Now);
            }

            Employee e = new Employee();

            e.EmployeeID = empid;
            e.FirstName = fname;
            e.LastName = lname;
            e.Salary = sal;
            e.DateofJoining = doj;

            bsl.HttpPostEmployee(e);

        }

        public void ModifyEmployee(Employee employee)
        {
            using (filelogger = new FileLogger()) 
            {
                this.filelogger.Log("ModifyEmployee() called at:" + DateTime.Now);
            }

            Employee e = new Employee();

            e.EmployeeID = employee.EmployeeID;
            e.FirstName = employee.FirstName;
            e.LastName = employee.LastName;
            e.Salary = employee.Salary;
            e.DateofJoining = employee.DateofJoining;

           bsl.PutEmployee(e);

           // bsl.PutEmployee(employee);
        }


       

        public void RemoveEmployee(int empid)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("RemoveEmployee() called at:" + DateTime.Now);
            }

            Employee e = new Employee();
            e.EmployeeID = empid;

            bsl.DeleteEmployee(empid);
        }

        public Employee? GetEmployeeById(int empid)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("GetEmployeeById() called at:" + DateTime.Now);
            }

            Employee? employee = bsl.GetEmployeeById(empid);

            if (employee == null)
            {
                Console.WriteLine($"employee with id {empid} not found");
            }

            
            Console.WriteLine("FirstName:  " + employee.FirstName);
            Console.WriteLine("LastName:  " + employee.LastName);
            Console.WriteLine("Salary:  " + employee.Salary);
            Console.WriteLine("DateofJoining" + employee.DateofJoining);


            return employee;


        }
        public void addEmployeeToFile()
        {
            this.bsl.AddEmployeeToFile();
        }

        public void displayEmployeeFromFile()
        {
            this.bsl.DisplayEmployeeFromFile();
        }


        public void PersistData()
        {
            this.bsl.PersistData();
        }
        public void ReadData()
        {
            this.bsl.ReadData();
        }


    }


    public class RevisedEmployee
    {
        public int EmpId { get; set; }
        public string? FName { get; set; }
        public string? LName { get; set; }
        public int Sal { get; set; }
        public DateTime Doj { get; set; }


        public override string ToString()
        {


            //use string builder

            StringBuilder sb = new StringBuilder();

            sb.Append("Employee Id:" + this.EmpId);

            sb.Append("\n Employee FirstName:" + this.FName);

            sb.Append("\n Employee LastName:" + this.LName);

            sb.Append("\n Employee Salary:" + this.Sal);

            sb.Append("\n Employee DateOfJoining:" + this.Doj);

            return sb.ToString();


        }

    }
}
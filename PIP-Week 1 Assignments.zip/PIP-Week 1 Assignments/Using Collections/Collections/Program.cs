﻿using BL;
using EntityClassesLib;
using LoggerLib;

using ValidationLayer;

namespace FrontEnd
{
    class Program
    {
        static BusinessLogic bl = new BusinessLogic();
        static bool IsDataRetrieved = false;
        static void Main()
        {

            int choice = -1;
            do
            {
                Console.Clear();
                Console.WriteLine("1. GET ALL EMPLOYEES");
                Console.WriteLine("2. ADD A NEW EMPLOYEE");
                Console.WriteLine("3. EDIT EMPLOYEE DETAILS");
                Console.WriteLine("4. DELETE A EMPLOYEE");
                Console.WriteLine("5. GET EMPLOYEE BY ID ");
                Console.WriteLine("6. ADD EMPLOYEE RECORDS TO FILE");
                Console.WriteLine("7. DISPLAY EMPLOYEE DETAILS FROM FILE");

                Console.WriteLine("8. QUIT ");
                if (File.Exists("c:\\employees.json"))
                {
                    if (IsDataRetrieved == false)
                    {
                        bl.ReadData();
                        IsDataRetrieved = true;
                    }
                }

                Console.Write("\nEnter your choice (1-8): ");
                choice = int.Parse(Console.ReadLine());

                //you can use a switch or if else to check the choice
                switch (choice)
                {
                    case 1:
                        GetAllEmployees();
                        break;
                    case 2:
                        AddEmployee();
                        break;
                    case 3:
                        EditEmployee();
                        break;
                    case 4:
                        DeleteEmployee();
                        break;
                    case 5:
                        GetEmployeeById();
                        break;
                    case 6:
                        addEmployeeToFile();
                        break;
                    case 7:
                        displayEmployeeFromFile();
                        break;


                    case 8:
                        bl.PersistData();
                        Console.WriteLine("Thank you for using this application");
                        break;
                    default:
                        Console.WriteLine("Invalid Choice.Press any key to continue");
                        Console.ReadKey();
                        break;
                }

            } while (choice != 8);

        }
        static void GetAllEmployees()
        {
            Console.Clear();

            var result = bl.ObtainAllEmployeesList();

            if (result.Count() == 0)
            {
                Console.WriteLine("No Employee to show");
            }
            else
            {
                foreach (var employee in result)
                {
                    Console.WriteLine(employee);
                }
            }
            Console.ReadKey();
        }

        static void AddEmployee()
        {
            Console.Clear();
            Console.Write("Enter Employee id: ");
            int empid = 0;
            try
            {
                empid = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("employee ID can contain only numbers");
                Console.Write("Re-Enter Employee id: ");
                empid = int.Parse(Console.ReadLine());

            }

            Console.Write("Enter Employee FirstName: ");
            string fname = Console.ReadLine();

            if (EmployeeValidator.IsValid(fname) == false)
            {
                Console.WriteLine("Employee FirstName is not valid");
                Console.ReadKey();
                return;
            }

            Console.Write("Enter Employee LastName: ");
            string lname = Console.ReadLine();

            if (EmployeeValidator.IsValid(lname) == false)
            {
                Console.WriteLine("Employee LastName is not valid");
                Console.ReadKey();
                return;
            }

            Console.Write("Enter Employee salary: ");
            int sal = 0;
            try
            {
                sal = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine(" Salary can contain only numbers");
                Console.WriteLine("Re-Enter Employee Salary");
                sal = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Enter Employee Date of Joining");
            DateTime doj = DateTime.Parse(Console.ReadLine());

            if (EmployeeValidator.DateValidate(doj) == false)
            {
                Console.WriteLine("Date must be less than present date");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Employee details added Successfully!");


            // Wait for the user to press a key before exiting
            Console.ReadKey();

            bl.InsertEmployee(empid, fname, lname, sal, doj);

        }
        static void EditEmployee()

        {
            Console.WriteLine("Enter Employee ID:");
            int empid = 0;
            try
            {
                empid = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("EmployeeId can contain only numbers");
                Console.Write("Re-Enter Employee id: ");
                empid = int.Parse(Console.ReadLine());
            }

            Console.Write("Enter Employee FirstName: ");
            string fname = Console.ReadLine();
            if (EmployeeValidator.IsValid(fname) == false)
            {
                Console.WriteLine("Employee FirstName is not valid");
                Console.ReadKey();
                return;
            }

            Console.Write("Enter Employee LastName: ");
            string lname = Console.ReadLine();
            if (EmployeeValidator.IsValid(lname) == false)
            {
                Console.WriteLine("Employee LastName is not valid");
                Console.ReadKey();
                return;
            }


            Console.Write("Enter Employee salary: ");
            int sal = 0;
            try
            {
                sal = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("salary can contain only numbers");
                Console.WriteLine("Re-Enter Employee Salary");
                sal = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Enter Employee DateofJoining");
            DateTime doj = DateTime.Parse(Console.ReadLine());

            Employee e = new Employee()  {

                EmployeeID= empid,
                FirstName = fname, 
                LastName = lname,
                Salary= sal,
                DateofJoining= doj,   
                
            };
            bl.ModifyEmployee(e);


            //bl.ModifyEmployee(empid, fname, lname, sal, doj);
            Console.ReadKey();


        }

        static void DeleteEmployee()
        {
            Console.WriteLine("Enter Employee ID:");
            int empid = int.Parse(Console.ReadLine());

            Console.WriteLine("Employee details deleted Successfully!");

            bl.RemoveEmployee(empid);
            Console.ReadKey();
        }

        static void GetEmployeeById()
        {
            Console.WriteLine("Enter Employee ID:");
            int empid = int.Parse(Console.ReadLine());

            var employee = bl.GetEmployeeById(empid);

            if (employee == null)
            {
                Console.WriteLine("Employee not found.");
            }
            else
            {
                Console.WriteLine(employee);
            }

            Console.ReadKey();
        }

        static void addEmployeeToFile()
        {
            bl.addEmployeeToFile();
        }

        static void displayEmployeeFromFile()
        {
            bl.displayEmployeeFromFile();
        }

    }
}


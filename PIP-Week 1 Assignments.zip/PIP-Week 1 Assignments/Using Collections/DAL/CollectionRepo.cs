﻿using EntityClassesLib;

namespace DAL
{
    public class CollectionRepo : IRepository<Employee>
    {
        private List<Employee> employees;
        private string filePath = @"C:\collections\collections.txt";


        private int employeeId;

        public CollectionRepo()
        {
            employees = new List<Employee>();
        }
        public void AddEmployee(Employee employee)
        {
            employees.Add(employee);
        }

        public void AddToFile(List<Employee> employees)
        {
            if (employees.Count > 0)
            {
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    foreach (Employee employee in employees)
                    {
                        string empDetails = string.Format("{0},{1},{2},{3},{4}", employee.EmployeeID, employee.FirstName, employee.LastName, employee.Salary, employee.DateofJoining);
                        sw.WriteLine(empDetails);
                    }
                }
                Console.WriteLine("Employee records added to file successfully!");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("No employee records found to add to file.");
                Console.ReadKey();
            }
        }

        public void DeleteEmployee(int employeeId)
        {
            Employee employee = employees.Find(e => e.EmployeeID == employeeId);
            if (employee != null)
            {
                employees.Remove(employee);
                
                
            }
        }

        public List<Employee> GetAllEmployees()
        {
            return employees;
        }

       

       

        public void PersistData()
        {
           
        }

        public void ReadData()
        {
           
        }

       

        public Employee GetEmployeeByID(int employeeID)
        {
            return employees.Find(e => e.EmployeeID == employeeID);


        }

        public void GetEmployeesFromFile()
        {
            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();

                        string[] values = line.Split(',');

                        Employee e = new Employee();

                        e.EmployeeID = int.Parse(values[0]);
                        e.FirstName = values[1];
                        e.LastName = values[2];
                        e.Salary = int.Parse(values[3]);
                        e.DateofJoining = DateTime.Parse(values[4]);

                        Console.WriteLine($"empid: {e.EmployeeID}, fname: {e.FirstName}, lname: {e.LastName}, Sal: {e.Salary}, doj : {e.DateofJoining}");
                        //Console.WriteLine("Employee records displayed from file successfully!");

                        Console.ReadLine();

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"There is no employee to Display: {ex.Message}");
                //Console.WriteLine("No employee records found to display from file");
                //Console.ReadKey(false);
            }
        }

        public void UpdateEmployee(Employee emp)
        {
            Employee existingEmployee = employees.Find(e => e.EmployeeID == emp.EmployeeID);
            if (existingEmployee != null)
            {
                existingEmployee.FirstName = emp.FirstName;
                existingEmployee.LastName = emp.LastName;
                existingEmployee.Salary = emp.Salary;
                existingEmployee.DateofJoining = emp.DateofJoining;

                Console.WriteLine("Employee details updated successfullt!");
            }
            else
            {
                throw new Exception("Employee not found!");
            }
            
        }
    }
}
﻿using EntityClassesLib;
using ValidationLayer;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Numerics;
using System.Text.Json;

namespace DAL
{
    public class EmployeeDBRepo : IRepository
    {
        private SqlConnection? conn;
        private SqlCommand? comm;
        private SqlDataReader? reader;

        List<Employee> allemployees = new List<Employee>();
        private string filePath = @"C:\employees\employees.txt";
        public EmployeeDBRepo()
        {
            this.conn = new SqlConnection("server=CTAADPG038PAB\\SQLEXPRESS;database=TrainingDB;uid=sa;pwd=Password_123;TrustServerCertificate=true;");
            conn.Open();
                                   
            Console.WriteLine("DAL Connected to SQL Server");
        }      

        public void AddNewEmployee(Employee e)
        {
            comm = new SqlCommand();
            comm.Connection = conn;

            // to call a proc
            comm.CommandType = CommandType.StoredProcedure;
            comm.CommandText = "InsertEmployee";

            //tell the Sql Command about the parameters
            comm.Parameters.AddWithValue("@empid", e.EmployeeID);
            comm.Parameters.AddWithValue("@fname", e.FirstName);
            comm.Parameters.AddWithValue("@lname", e.LastName);
            comm.Parameters.AddWithValue("@sal", e.Salary);
            comm.Parameters.AddWithValue("@doj", e.DateofJoining);

            int recordsinserted = comm.ExecuteNonQuery();
            Console.WriteLine("{0}records inserted", recordsinserted);
       
        }            
        public void EditEmployee(int employeeid, Employee e)
        {
            string sql = "UPDATE employees SET firstname=@fname, lastname=@lname, salary=@sal, Dateofjoining=@doj  WHERE employeeid=@empid";
            comm = new SqlCommand(sql, conn);
            comm.Parameters.AddWithValue("@empid", employeeid);
            comm.Parameters.AddWithValue("@fname", e.FirstName);
            comm.Parameters.AddWithValue("@lname", e.LastName);
            comm.Parameters.AddWithValue("@sal", e.Salary);
            comm.Parameters.AddWithValue("@doj", e.DateofJoining);

            int recordsupdated = comm.ExecuteNonQuery();
            if (recordsupdated > 0)
            {
                Console.WriteLine("{0} records updated", recordsupdated);
            }
            else
            {
                Console.WriteLine("Employee id not found for updation");
            }

           // reader.Close();

        }
        public void DeleteEmployee(int employeeid)
        {
            
            string sql = "DELETE FROM employees WHERE employeeid=@empid";
            comm = new SqlCommand(sql, conn);
            comm.Parameters.AddWithValue("@empid", employeeid);

          
            int recordsdeleted = comm.ExecuteNonQuery();
            if(recordsdeleted > 0) 
            {
                Console.WriteLine("{0} records deleted", recordsdeleted);
            }
            else
            {
                Console.WriteLine("Employee id not found for deletion");
            }
            

           // reader.Close();
        }
        
        public List<Employee> GetAllEmployees()
        {
            string sql = "select * from employees";
            SqlCommand comm = new SqlCommand(sql,conn);
            comm.Connection = conn;     //associate command with connection

            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {
                Console.WriteLine("No Employee to show");
            }
            else
            {
                while (reader.Read())
                {
                    //read each now one by one and get the columns
                    Employee e = new Employee();

                    e.EmployeeID = (int)reader["employeeid"];
                    e.FirstName = reader["firstname"].ToString();
                    e.LastName = reader["lastname"].ToString() ;
                    e.Salary = (int)reader["salary"];
                    e.DateofJoining = (DateTime)reader["dateofjoining"];
                    allemployees.Add(e);                   
                }
            }
            reader.Close();

            return allemployees;
        }       
        public Employee GetEmployeeById(int employeeid)
        {
            string sql = "SELECT * FROM employees WHERE employeeid=@empid";
            comm = new SqlCommand(sql, conn);
            comm.Parameters.AddWithValue("@empid", employeeid);
            reader = comm.ExecuteReader();

            if (reader.HasRows == false)
            {
                Console.WriteLine("Employee not found");
                return null;
            }

            Employee e = new Employee();
            while (reader.Read())
            {
                    
                    e.EmployeeID = (int)reader["employeeid"];
                    e.FirstName = reader["firstname"].ToString();
                    e.LastName = reader["lastname"].ToString();
                    e.Salary = (int)reader["salary"];
                    e.DateofJoining = (DateTime)(reader["dateofjoining"]);                  
            }

            Console.WriteLine("FirstName:  " + e.FirstName);
            Console.WriteLine("LastName:  " + e.LastName);
            Console.WriteLine("Salary:  "+ e.Salary);
            Console.WriteLine("DateofJoining" + e.DateofJoining);

            reader.Close ();
            return e;    
           
        }
       
       // --------------------------------------------
        public void PersistData()
        {
            //// use JsonSerializer here to persist the collection
            ////create a stream which points to a file
            //FileStream fs = new FileStream("c:\\employees.json", FileMode.Create, FileAccess.Write);

            ////use JsonSerializer to persist the collection
            //JsonSerializer.Serialize<List<Employee>>(fs, this.allemployees);

            ////close the file stream
            //fs.Close();
            //Console.WriteLine("Customer data persisted successfully");
        }

        public void ReadData()
        {
            //FileStream fs = new FileStream("c:\\employees.json", FileMode.Open, FileAccess.Read);

            ////code for deserialization
            //this.allemployees = JsonSerializer.Deserialize<List<Employee>>(fs);
            //Console.WriteLine("Employee Data retreived successfully");
            //fs.Close();
        }


        public void Dispose()
        {
            if (this.conn != null)
            {
                conn.Close();
                Console.WriteLine("SQL Connection Closed");
            }
        }

        public void AddEmployeesToFile(List<Employee> employees)
        {
            if (employees.Count > 0)
            {
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    foreach (Employee employee in employees)
                    {
                        string empDetails = string.Format("{0},{1},{2},{3},{4}", employee.EmployeeID, employee.FirstName, employee.LastName, employee.Salary, employee.DateofJoining);
                        sw.WriteLine(empDetails);
                    }
                }
                Console.WriteLine("Employee records added to file successfully!");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("No employee records found to add to file.");
                Console.ReadKey();
            }
        }

        public void  GetEmployeesFromFile()
        {
           // string filePath = @"C:\employees\employees.txt";

            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();

                        string[] values = line.Split(',');

                        Employee e = new Employee();

                        e.EmployeeID = int.Parse(values[0]);
                        e.FirstName = values[1];
                        e.LastName = values[2];
                        e.Salary = int.Parse(values[3]);
                        e.DateofJoining = DateTime.Parse(values[4]);

                        Console.WriteLine($"empid: {e.EmployeeID}, fname: {e.FirstName}, lname: {e.LastName}, Sal: {e.Salary}, doj : {e.DateofJoining}");
                        //Console.WriteLine("Employee records displayed from file successfully!");

                        Console.ReadLine();
                
                    }
                }
            }
            catch (Exception ex)
            {
                 Console.WriteLine($"There is no employee to Display: {ex.Message}");
                //Console.WriteLine("No employee records found to display from file");
                //Console.ReadKey(false);
            }           
        }
    }
}

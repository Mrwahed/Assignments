﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityClassesLib;

namespace DAL
{
    public interface IRepository
    {
        List<Employee> GetAllEmployees();
        void AddNewEmployee(Employee e);
        void EditEmployee(int employeeid, Employee e);
        void DeleteEmployee(int employeeid);
        Employee GetEmployeeById(int employeeid);
        void AddEmployeesToFile(List<Employee> employees);
        void  GetEmployeesFromFile();
    }
}

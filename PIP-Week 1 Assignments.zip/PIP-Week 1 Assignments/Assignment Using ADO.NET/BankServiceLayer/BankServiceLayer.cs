﻿using DAL;
using EntityClassesLib;

namespace BankServiceLayer
{
    public class BankServiceLayer
    {
        private EmployeeDBRepo dal = new EmployeeDBRepo();

        public List<Employee> HttpGetAllEmployees()
        {
            return this.dal.GetAllEmployees();
        }
        public void HttpPostEmployee(Employee newemployee)
        {
            this.dal.AddNewEmployee(newemployee);
        }
        public void PutEmployee(int empid, Employee modifiedemployee)
        {
            this.dal.EditEmployee(empid, modifiedemployee);
        }
        public void DeleteEmployee(int empid)
        {
            this.dal.DeleteEmployee(empid);
        }
        public void AddEmployeeToFile()
        {
            List<Employee> temp = dal.GetAllEmployees();
            dal.AddEmployeesToFile(temp);
        }

        public void DisplayEmployeeFromFile()
        {
            List<Employee> tmp = dal.GetAllEmployees();
            dal.GetEmployeesFromFile();
        }

        public Employee GetEmployeeById(int empid) => this.dal.GetEmployeeById(empid);

        public void PersistData()
        {
            this.dal.PersistData();
        }

        public void ReadData()
        {
            this.dal.ReadData();
        }



    }
}
﻿using EntityClassesLib;
using System.Text.RegularExpressions;

namespace ValidationLayer
{
    public class EmployeeValidator
    {
   
        //FirstName and LastName are mandatory.
        public static bool IsValid(string str)
        {
            Regex val = new Regex(@"^\d{1,7}$");
            bool temp = true;
            
            if (string.IsNullOrEmpty(str) || val.IsMatch(str.ToString()))
            {
                temp = false;
            }
            return temp;
        }

        //DateOfJoining cannot be greater than current date.
        public static bool DateValidate(DateTime dt)
        {
            bool temp = true;
            if (dt > DateTime.Now)
                temp = false;
            return temp;
        }

        

        //// DateOfJoining cannot be greater than current date
        //if (employee.DateofJoining > DateTime.Now)
        //    return false;

        //return true;
    }



}
﻿using System.IO;
using DAL;
namespace LoggerLib
{
    public class FileLogger : ILogger
    {
        public StreamWriter? sw = null;
        EmployeeDBRepo dal = new EmployeeDBRepo();
        public void Log(string message = "")
        {

            //use File I/O APIs here
            //check if file named"EmployeeRecords.txt exist in the folder named "EmployeeRecords"

            if (!Directory.Exists("c:\\EmployeeRecords"))
            {
                Directory.CreateDirectory("c:\\EmployeeRecords");
                Console.WriteLine("Directory created for EmployeeRecords");
            }
            else
            {
                Console.WriteLine("Directory already exists for EmployeeRecords");
            }
            //check if a file named logs.txt exists in the c:\logs folder

            FileInfo fi = new FileInfo("c:\\EmployeeRecords\\EmployeeRecords.txt");

            if (!fi.Exists)
            {
                fi.Create();
                Console.WriteLine("File created for writing EmployeeRecords");
            }
            else
            {
                Console.WriteLine("File already exists for writing EmployeeRecords");

            }
            sw = new StreamWriter("c:\\EmployeeRecords\\EmployeeRecords.txt", true);  //opens the file in append mode

            //write the EmployeeRecords into the file

            sw.WriteLine("{0} written at {1}", message, DateTime.Now.ToLongTimeString());
        }

        public void Dispose()
        {
            //write code to close the file
            if (this.sw != null)
            {
                sw.Close();
                Console.WriteLine("EmployeeRecords file closed in Dispose()");
            }
        }
    }
}


function displayMax(arg1, arg2, arg3) {
    return Math.max(arg1, arg2, arg3);
}

//let nums = [7, 2, 9];
//displayMax(nums);
console.log(`the maximum number is :${displayMax(7, 2, 9)}`);
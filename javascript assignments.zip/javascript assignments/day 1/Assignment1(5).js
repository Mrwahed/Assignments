let arr = [7,6,5,4,3,2,1];
let reverseArr=console.log(arr.reverse())

